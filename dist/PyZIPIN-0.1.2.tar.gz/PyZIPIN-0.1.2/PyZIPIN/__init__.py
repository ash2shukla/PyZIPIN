
from .ZIPDecode import decode,encode

'''
decode: Convert ZIP to Information(District, State etc.).
encode: Convert District to ZIP.
'''
